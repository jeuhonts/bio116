Bio 116 interactive tutorials: sequence alignment and database searching

Open index.html in a web browser (Chrome, Firefox, Safari or Edge) to start.
Every page is a single self-contained file and works offline. An internet
connection is needed only for the web fonts and for outside links (NCBI,
UniProt, RCSB PDB, EBI, DOIs).

Core tutorials
  1  globin-pairwise-alignment.html     Aligning the Globins
  2  blast-algorithm.html               Inside BLAST (including PSI-BLAST)
  3  scoring-matrices.html              PAM and BLOSUM
  4  hmmer-profile-hmms.html            Profile HMMs and HMMER
  5  multiple-sequence-alignment.html   Aligning Many Globins
  6  molecular-phylogeny.html           Globin Family Trees
  7  structural-alignment.html          Superposing the Globins
Supplemental
  S1 ncbi-blast-web.html                BLAST at NCBI
  S2 blast-command-line.html            BLAST on the command line

Keep all files in the same folder so the links in index.html work.
